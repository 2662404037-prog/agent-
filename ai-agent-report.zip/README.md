# AI Agent 使用情况（网页版）

一页式报告，覆盖 2026-09-18 至 2026-10-10 在 Codex 上的使用记录。
纯静态，无外部依赖、无构建步骤，可直接放到 GitHub Pages 发布。

## 文件

- `index.html` — 报告正文，单文件（内联样式、内联图表），自适应手机和桌面，自动跟随系统深浅色。

## 发布到 GitHub Pages

1. 新建一个仓库，例如 `ai-agent-report`。
2. 把 `index.html` 放到仓库根目录（或 `docs/` 目录）。
3. 仓库 **Settings → Pages**：
   - Source 选 **Deploy from a branch**；
   - Branch 选 `main`，目录选 `/ (root)`（若放在 `docs/` 则选 `/docs`）；
   - 保存。
4. 等 1 分钟左右，访问 `https://<你的用户名>.github.io/ai-agent-report/`。

命令行版本：

```bash
git init
git add index.html
git commit -m "Add AI Agent usage report"
git branch -M main
git remote add origin https://github.com/<你的用户名>/ai-agent-report.git
git push -u origin main
```

推送后在 Settings → Pages 里开启即可。

## 数据口径

统计自本机 `.codex` 会话日志（`sessions` + `archived_sessions`）：

- 47 个用户会话、191 条用户指令、952 条 Agent 回复、2926 次工具调用；
- 另有 49 次后台自动安全复核（Guardian review），单独计数；
- token 为各会话累计口径相加（约 16.2 亿），仅表示量级。

若要更新报告，重新统计日志并替换 `index.html` 即可。